<template>
  <div class="hello">
    OK
  </div>
</template>

<script>
module.exports = {
  name: "ok",
};
</script>

<style>
.hello {
  background-color: #ff0;
}
</style>


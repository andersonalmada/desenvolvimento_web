<template>
  <div class="bg-primary">
    <p>Hello World</p>
    <ok></ok>
  </div>
</template>

<script>
var Ok = httpVueLoader('./ok.vue') 

module.exports = {
  name: "hello",
  components: {
    ok: Ok
  }
};
</script>
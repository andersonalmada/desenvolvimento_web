var hello = httpVueLoader('./vue/hello.vue') 
var ok = httpVueLoader('./vue/ok.vue') 

var app = new Vue({
    el: '#app',
    components: {
        hello1: hello,
        ok1: ok
    },
    data: {
        title: "Aula WEB"
    }
});


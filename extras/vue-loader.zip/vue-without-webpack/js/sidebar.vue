<template>
<div class="bg-primary">Burası Sidebar.</div>
</template>

<script>
module.exports = {
  methods: {}
}
</script>
